# Classroom App Finder

A local dashboard where you enter your Classroom assignments by hand
(since automated Google API/OAuth access was blocked by the school
account's admin), and AI matches each one to the app it needs
(IXL, Khan Academy, Kahoot, etc.) with a direct link.

## Setup

1. **Install dependencies**
   ```
   npm install
   ```

2. **(Optional) Create your `.env.local`**
   ```
   cp .env.local.example .env.local
   ```
   Only needed if you want the AI fallback matcher — paste in an
   `ANTHROPIC_API_KEY` from console.anthropic.com. Without it, the
   app still works using the built-in keyword matcher.

3. **Run it**
   ```
   npm run dev
   ```
   Open http://localhost:3000

## How to use it

1. Open your Classroom "To Do" page in another tab.
2. For each assignment, copy the title (and description, if there is
   one) into the form and click "Add & find app."
3. The app checks its keyword list first, then (if you set an API
   key) asks Claude for a best guess on anything it doesn't recognize.
4. Click "Open in Classroom" or "Open [App]" to jump straight there.

Your list is saved in your browser (localStorage), so it's still
there next time you open the app — no account or server database
needed.

## How matching works

- `lib/appCatalog.js` has a list of common apps + keywords — this
  runs first, is free, and is instant. Add more apps/keywords here
  any time.
- If nothing matches and `ANTHROPIC_API_KEY` is set, it asks Claude
  to pick the best fit from the same app list.
- If neither matches, it shows "No app detected."

## Why manual entry instead of live sync?

This school account blocks both the Classroom API (for OAuth apps)
and Google Takeout exports for Classroom data. Both are deliberate
admin-level restrictions, so the only way to pull data automatically
would be to ask the school's IT/Workspace admin to allowlist an app
for the domain — that's the legitimate fix if you want a live
version later.
