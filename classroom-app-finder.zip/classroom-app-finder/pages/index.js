import { useEffect, useState } from "react";

const STORAGE_KEY = "classroom-app-finder-assignments";

export default function Home() {
  const [assignments, setAssignments] = useState([]);
  const [form, setForm] = useState({ course: "", title: "", description: "", link: "" });
  const [matchingId, setMatchingId] = useState(null);

  // Load saved assignments on first render
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        setAssignments(JSON.parse(saved));
      } catch {
        // ignore corrupt storage
      }
    }
  }, []);

  // Persist whenever the list changes
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(assignments));
  }, [assignments]);

  function addAssignment(e) {
    e.preventDefault();
    if (!form.title.trim()) return;

    const newItem = {
      id: Date.now(),
      course: form.course.trim(),
      title: form.title.trim(),
      description: form.description.trim(),
      link: form.link.trim(),
      matchedApp: null,
    };
    setAssignments((prev) => [newItem, ...prev]);
    setForm({ course: "", title: "", description: "", link: "" });

    // Automatically try to match right after adding
    findApp(newItem);
  }

  async function findApp(item) {
    setMatchingId(item.id);
    try {
      const res = await fetch("/api/match", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: item.title, description: item.description }),
      });
      const data = await res.json();
      setAssignments((prev) =>
        prev.map((a) => (a.id === item.id ? { ...a, matchedApp: data.match || "none" } : a))
      );
    } catch (err) {
      console.error(err);
    } finally {
      setMatchingId(null);
    }
  }

  function removeAssignment(id) {
    setAssignments((prev) => prev.filter((a) => a.id !== id));
  }

  return (
    <div className="wrap">
      <header className="header">
        <h1>📚 Classroom App Finder</h1>
      </header>
      <p className="subtitle">
        Add your assignments below — the AI will figure out which app each one needs
        and give you a direct link.
      </p>

      <form className="card form" onSubmit={addAssignment}>
        <input
          placeholder="Course (optional)"
          value={form.course}
          onChange={(e) => setForm({ ...form, course: e.target.value })}
        />
        <input
          placeholder="Assignment title *"
          value={form.title}
          onChange={(e) => setForm({ ...form, title: e.target.value })}
          required
        />
        <textarea
          placeholder="Assignment description / instructions (paste from Classroom)"
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
          rows={3}
        />
        <input
          placeholder="Link to this assignment in Classroom (optional)"
          value={form.link}
          onChange={(e) => setForm({ ...form, link: e.target.value })}
        />
        <button className="btn" type="submit">Add & find app</button>
      </form>

      <div className="grid">
        {assignments.map((a) => (
          <div className="card" key={a.id}>
            {a.course && <div className="course">{a.course}</div>}
            <h3>{a.title}</h3>
            {a.description && <p className="desc">{a.description}</p>}

            <div className="actions">
              {a.link && (
                <a href={a.link} target="_blank" rel="noreferrer" className="link">
                  Open in Classroom
                </a>
              )}

              {matchingId === a.id && <span className="no-match">Matching...</span>}

              {a.matchedApp && a.matchedApp !== "none" && (
                <a href={a.matchedApp.url} target="_blank" rel="noreferrer" className="link app-link">
                  Open {a.matchedApp.app} ↗
                </a>
              )}
              {a.matchedApp === "none" && <span className="no-match">No app detected</span>}

              <button className="btn secondary small" onClick={() => findApp(a)}>
                Re-check app
              </button>
              <button className="btn secondary small" onClick={() => removeAssignment(a.id)}>
                Remove
              </button>
            </div>
          </div>
        ))}
      </div>

      {assignments.length === 0 && <p>No assignments added yet — add one above.</p>}
    </div>
  );
}
