const { matchAssignmentToApp } = require("../../lib/matcher");

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Use POST" });
  }

  const { title, description } = req.body || {};
  if (!title) {
    return res.status(400).json({ error: "title is required" });
  }

  try {
    const match = await matchAssignmentToApp({ title, description });
    res.status(200).json({ match });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
}
